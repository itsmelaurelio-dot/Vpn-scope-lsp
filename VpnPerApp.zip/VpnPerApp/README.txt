VPN Per-App (modul LSPosed)
1. Edit app/src/main/java/com/hanaka/vpnperapp/Config.java -> isi ALLOWED dengan package name app yang mau di-VPN.
2. Build: Build > Build APK(s) (debug sudah cukup), lalu install APK-nya.
3. LSPosed > Modul > aktifkan "VPN Per-App" > centang HANYA app VPN-mu di scope.
4. Force stop app VPN (atau reboot), sambungkan ulang VPN.
5. Cek LSPosed > Log, cari "[VpnPerApp]".
