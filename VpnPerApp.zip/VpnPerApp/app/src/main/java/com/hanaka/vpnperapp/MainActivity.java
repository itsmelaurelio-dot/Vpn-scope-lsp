package com.hanaka.vpnperapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    static final String PREF_NAME = "config";
    static final String KEY_ALLOWED = "allowed";

    private static class Item {
        String pkg;
        String label;
        Drawable icon;
    }

    private SharedPreferences prefs;
    private final Set<String> selected = new HashSet<>();
    private final List<Item> all = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private ListAdapter adapter;
    private TextView status;

    @SuppressLint("WorldReadableFiles")
    @SuppressWarnings("deprecation")
    private SharedPreferences openPrefs() {
        try {
            // LSPosed/Vector mengalihkan ini ke folder yang bisa dibaca hook.
            return getSharedPreferences(PREF_NAME, Context.MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            return null;
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        status = new TextView(this);
        status.setTextSize(13);
        status.setPadding(dp(16), dp(12), dp(16), dp(4));
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        prefs = openPrefs();
        if (prefs == null) {
            status.setTextColor(Color.parseColor("#FF8A80"));
            status.setText("Framework belum mengaktifkan penyimpanan bersama untuk modul ini.\n"
                    + "Pastikan modul VPN Per-App sudah AKTIF di Vector/LSPosed, lalu buka ulang app ini.\n"
                    + "Sementara itu hook memakai daftar dari allowed.txt.");
            setContentView(root);
            return;
        }

        Set<String> saved = prefs.getStringSet(KEY_ALLOWED, null);
        if (saved != null) {
            selected.addAll(saved);
        } else {
            // Belum pernah disimpan: hook memakai daftar bawaan, jadi tampilkan itu.
            Collections.addAll(selected, Config.ALLOWED);
        }

        EditText search = new EditText(this);
        search.setHint("Cari app...");
        search.setSingleLine(true);
        search.setPadding(dp(16), dp(8), dp(16), dp(8));
        root.addView(search, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ListView list = new ListView(this);
        adapter = new ListAdapter();
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        list.setOnItemClickListener((parent, view, position, id) -> {
            Item it = shown.get(position);
            if (selected.contains(it.pkg)) {
                selected.remove(it.pkg);
            } else {
                selected.add(it.pkg);
            }
            prefs.edit().putStringSet(KEY_ALLOWED, new HashSet<>(selected)).apply();
            adapter.notifyDataSetChanged();
            updateStatus();
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        setContentView(root);
        updateStatus();
        loadApps();
    }

    private void updateStatus() {
        status.setTextColor(Color.parseColor("#9E9E9E"));
        status.setText("Dipilih: " + selected.size()
                + " app. Hanya app yang dicentang yang lewat VPN."
                + " Perubahan berlaku saat VPN disambung ulang.");
    }

    private void loadApps() {
        final PackageManager pm = getPackageManager();
        new Thread(() -> {
            List<Item> tmp = new ArrayList<>();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            for (ApplicationInfo ai : apps) {
                if (ai.packageName.equals(getPackageName())) continue;
                boolean hasLauncher = pm.getLaunchIntentForPackage(ai.packageName) != null;
                if (!hasLauncher && !selected.contains(ai.packageName)) continue;
                Item it = new Item();
                it.pkg = ai.packageName;
                it.label = String.valueOf(pm.getApplicationLabel(ai));
                it.icon = pm.getApplicationIcon(ai);
                tmp.add(it);
            }
            Collections.sort(tmp, (a, b) -> {
                boolean sa = selected.contains(a.pkg);
                boolean sb = selected.contains(b.pkg);
                if (sa != sb) return sa ? -1 : 1;
                return a.label.compareToIgnoreCase(b.label);
            });
            runOnUiThread(() -> {
                all.clear();
                all.addAll(tmp);
                applyFilter("");
            });
        }).start();
    }

    private void applyFilter(String query) {
        String q = query.trim().toLowerCase(Locale.ROOT);
        shown.clear();
        for (Item it : all) {
            if (q.isEmpty()
                    || it.label.toLowerCase(Locale.ROOT).contains(q)
                    || it.pkg.toLowerCase(Locale.ROOT).contains(q)) {
                shown.add(it);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private class ListAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int position) {
            return shown.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row;
            ImageView icon;
            TextView name;
            TextView pkgView;
            CheckBox cb;

            if (convertView == null) {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(16), dp(10), dp(16), dp(10));

                icon = new ImageView(MainActivity.this);
                row.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));

                LinearLayout texts = new LinearLayout(MainActivity.this);
                texts.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                tlp.leftMargin = dp(14);
                row.addView(texts, tlp);

                name = new TextView(MainActivity.this);
                name.setTextSize(16);
                texts.addView(name);

                pkgView = new TextView(MainActivity.this);
                pkgView.setTextSize(12);
                pkgView.setTextColor(Color.parseColor("#9E9E9E"));
                texts.addView(pkgView);

                cb = new CheckBox(MainActivity.this);
                cb.setClickable(false);
                cb.setFocusable(false);
                row.addView(cb);

                row.setTag(new View[]{icon, name, pkgView, cb});
            } else {
                row = (LinearLayout) convertView;
                View[] v = (View[]) row.getTag();
                icon = (ImageView) v[0];
                name = (TextView) v[1];
                pkgView = (TextView) v[2];
                cb = (CheckBox) v[3];
            }

            Item it = shown.get(position);
            icon.setImageDrawable(it.icon);
            name.setText(it.label);
            pkgView.setText(it.pkg);
            cb.setChecked(selected.contains(it.pkg));
            return row;
        }
    }
}
