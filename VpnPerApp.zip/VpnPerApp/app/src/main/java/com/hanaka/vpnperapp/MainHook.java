package com.hanaka.vpnperapp;

import android.net.VpnService;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "[VpnPerApp] ";
    private static final String BUILDER = "android.net.VpnService$Builder";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        // Jangan hook system server / modul ini sendiri.
        if ("android".equals(lpparam.packageName)
                || "com.hanaka.vpnperapp".equals(lpparam.packageName)) {
            return;
        }

        final ClassLoader cl = lpparam.classLoader;
        final String pkg = lpparam.packageName;

        try {
            // 1) Abaikan deny list bawaan app VPN. Android tidak mengizinkan
            //    allow list dan deny list dicampur, jadi deny list harus dibuang.
            XposedHelpers.findAndHookMethod(BUILDER, cl, "addDisallowedApplication",
                    String.class, new XC_MethodReplacement() {
                        @Override
                        protected Object replaceHookedMethod(MethodHookParam param) {
                            return param.thisObject; // Builder dikembalikan apa adanya
                        }
                    });

            // 2) Abaikan allow list bawaan app VPN juga, pakai milik kita saja.
            XposedHelpers.findAndHookMethod(BUILDER, cl, "addAllowedApplication",
                    String.class, new XC_MethodReplacement() {
                        @Override
                        protected Object replaceHookedMethod(MethodHookParam param) {
                            return param.thisObject;
                        }
                    });

            // 3) Sebelum TUN dibuat, suntikkan allow list kita.
            XposedHelpers.findAndHookMethod(BUILDER, cl, "establish", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    injectAllowList((VpnService.Builder) param.thisObject, pkg);
                }
            });

            XposedBridge.log(TAG + "hook terpasang di " + pkg + " (proses " + lpparam.processName + ")");
        } catch (Throwable t) {
            // Kalau app tidak memakai VpnService (kebanyakan app), abaikan saja.
            if (!(t instanceof ClassNotFoundException)
                    && !(t instanceof NoSuchMethodError)) {
                XposedBridge.log(TAG + "gagal hook " + pkg + ": " + t);
            }
        }
    }

    private static void injectAllowList(VpnService.Builder b, String vpnPkg) {
        int ok = 0;
        for (String p : Config.ALLOWED) {
            if (addOne(b, p)) ok++;
        }
        if (ok == 0) {
            XposedBridge.log(TAG + "tidak ada paket valid, pakai fallback " + Config.FALLBACK_PKG);
            addOne(b, Config.FALLBACK_PKG);
        } else {
            XposedBridge.log(TAG + "allow list diterapkan untuk " + ok + " app (VPN: " + vpnPkg + ")");
        }
    }

    private static boolean addOne(VpnService.Builder b, String p) {
        try {
            b.addAllowedApplication(p); // API resmi
            return true;
        } catch (Throwable first) {
            // Fallback: isi langsung ke VpnConfig di dalam Builder (lewat refleksi).
            try {
                Object cfg = XposedHelpers.getObjectField(b, "mConfig");
                Field f = cfg.getClass().getDeclaredField("allowedApplications");
                f.setAccessible(true);
                @SuppressWarnings("unchecked")
                List<String> list = (List<String>) f.get(cfg);
                if (list == null) {
                    list = new ArrayList<>();
                    f.set(cfg, list);
                }
                list.add(p);
                return true;
            } catch (Throwable second) {
                XposedBridge.log(TAG + "gagal menambah " + p + ": " + first + " | " + second);
                return false;
            }
        }
    }
}
