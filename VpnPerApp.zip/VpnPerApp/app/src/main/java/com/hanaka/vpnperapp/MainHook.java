package com.hanaka.vpnperapp;

import android.net.VpnService;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "[VpnPerApp] ";
    private static final String BUILDER = "android.net.VpnService$Builder";
    private static final String MODULE_PKG = "com.hanaka.vpnperapp";

    /** true saat kode modul sendiri yang memanggil addAllowedApplication,
     *  supaya hook di bawah tidak ikut memblokir panggilan kita. */
    private static final ThreadLocal<Boolean> INJECTING = new ThreadLocal<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if ("android".equals(lpparam.packageName)
                || "com.hanaka.vpnperapp".equals(lpparam.packageName)) {
            return;
        }

        final ClassLoader cl = lpparam.classLoader;
        final String pkg = lpparam.packageName;

        try {
            // 1) Buang deny list bawaan app VPN (tidak boleh dicampur dengan allow list).
            XposedHelpers.findAndHookMethod(BUILDER, cl, "addDisallowedApplication",
                    String.class, new XC_MethodReplacement() {
                        @Override
                        protected Object replaceHookedMethod(MethodHookParam param) {
                            return param.thisObject;
                        }
                    });

            // 2) Buang allow list bawaan app VPN, KECUALI panggilan dari modul ini.
            XposedHelpers.findAndHookMethod(BUILDER, cl, "addAllowedApplication",
                    String.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (!Boolean.TRUE.equals(INJECTING.get())) {
                                param.setResult(param.thisObject);
                            }
                        }
                    });

            // 3) Sebelum TUN dibuat, suntikkan allow list kita.
            XposedHelpers.findAndHookMethod(BUILDER, cl, "establish", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    injectAllowList((VpnService.Builder) param.thisObject, pkg);
                }
            });

            XposedBridge.log(TAG + "hook terpasang di " + pkg + " (proses " + lpparam.processName + ")");
        } catch (Throwable t) {
            if (!(t instanceof ClassNotFoundException)
                    && !(t instanceof NoSuchMethodError)) {
                XposedBridge.log(TAG + "gagal hook " + pkg + ": " + t);
            }
        }
    }

    private static void injectAllowList(VpnService.Builder b, String vpnPkg) {
        INJECTING.set(Boolean.TRUE);
        try {
            int ok = 0;
            for (String p : loadAllowed()) {
                if (addOne(b, p)) ok++;
            }
            if (ok == 0) {
                XposedBridge.log(TAG + "tidak ada paket valid, pakai fallback " + Config.FALLBACK_PKG);
                addOne(b, Config.FALLBACK_PKG);
            }
        } finally {
            INJECTING.remove();
        }
        XposedBridge.log(TAG + "VPN " + vpnPkg + " | allow list sebenarnya di Builder: " + dump(b));
    }

    /** Daftar dari UI modul (dibaca ulang tiap VPN tersambung); kalau belum ada, pakai Config/allowed.txt. */
    private static List<String> loadAllowed() {
        try {
            XSharedPreferences sp = new XSharedPreferences(MODULE_PKG, "config");
            if (sp.getFile().canRead()) {
                Set<String> set = sp.getStringSet("allowed", null);
                if (set != null) {
                    XposedBridge.log(TAG + "daftar dari UI modul: " + set);
                    return new ArrayList<>(set);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "gagal baca pengaturan UI: " + t);
        }
        XposedBridge.log(TAG + "memakai daftar bawaan (allowed.txt)");
        return new ArrayList<>(Arrays.asList(Config.ALLOWED));
    }

    private static boolean addOne(VpnService.Builder b, String p) {
        try {
            b.addAllowedApplication(p); // API resmi
            return true;
        } catch (Throwable first) {
            // Fallback: isi langsung ke VpnConfig di dalam Builder (lewat refleksi).
            try {
                Object cfg = XposedHelpers.getObjectField(b, "mConfig");
                Field f = cfg.getClass().getDeclaredField("allowedApplications");
                f.setAccessible(true);
                @SuppressWarnings("unchecked")
                List<String> list = (List<String>) f.get(cfg);
                if (list == null) {
                    list = new ArrayList<>();
                    f.set(cfg, list);
                }
                list.add(p);
                return true;
            } catch (Throwable second) {
                XposedBridge.log(TAG + "gagal menambah " + p + ": " + first + " | " + second);
                return false;
            }
        }
    }

    /** Baca isi allow list yang benar-benar ada di Builder, untuk verifikasi di log. */
    private static String dump(VpnService.Builder b) {
        try {
            Object cfg = XposedHelpers.getObjectField(b, "mConfig");
            return String.valueOf(XposedHelpers.getObjectField(cfg, "allowedApplications"));
        } catch (Throwable t) {
            return "(tidak terbaca: " + t + ")";
        }
    }
}
